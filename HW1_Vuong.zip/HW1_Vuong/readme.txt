It is necessary to import packages/libraries listed at the top of the file. 
I've included various comments for readers to better understand the source code.

Test data: test_file.txt
Training data: train_data.txt
Output result: output9.txt

Preprocessing and importing data is implemented on lines: 13-75
KNN Algorithm is implemented on lines: 78-129

The estimated runtime is between 8-12 minutes